# Netflix_Dashboard
A tableau dashboard visualising various KPI related to netflix.
a description of how the dashboard looks like 
![image](https://github.com/ashu-tosh272/Netflix_Dashboard/assets/73795415/f6708c04-e95b-44ea-aa18-075ac67f10d9)
